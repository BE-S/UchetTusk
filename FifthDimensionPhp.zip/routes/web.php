<?php

namespace Routes;

use App\Controller\TableController;
use Libs\Http\Route;

$route = new Route();

$route->get("/table/{subtopicId}", TableController::class, "index");